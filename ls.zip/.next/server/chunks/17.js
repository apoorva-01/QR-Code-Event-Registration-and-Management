"use strict";
exports.id = 17;
exports.ids = [17];
exports.modules = {

/***/ 3801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const registrationSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    email: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    mobile: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    prefix: {
        type: String,
        required: true
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    organisation: {
        type: String,
        required: false
    },
    registerationType: {
        type: String,
        required: true
    },
    attendance1: {
        type: Boolean,
        required: false,
        default: false
    },
    attendance2: {
        type: Boolean,
        required: false,
        default: false
    },
    address: {
        type: String,
        required: true
    }
});
registrationSchema.index({
    email: 1
}, {
    unique: true
});
registrationSchema.index({
    mobile: 1
}, {
    unique: true
});
const Registrations = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Registrations) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Registrations", registrationSchema, "registrations");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Registrations);


/***/ }),

/***/ 9972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};
async function connect() {
    if (connection.isConnected) {
        console.log("already connected");
        return;
    }
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections.length) > 0) {
        connection.isConnected = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState);
        if (connection.isConnected === 1) {
            console.log("use previous connection");
            return;
        }
        await mongoose__WEBPACK_IMPORTED_MODULE_0___default().disconnect();
    }
    const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true
    });
    console.log("new connection");
    connection.isConnected = db.connections[0].readyState;
}
async function disconnect() {
    if (connection.isConnected) {
        // if (process.env.NODE_ENV === 'production') {
        //   await mongoose.disconnect();
        //   connection.isConnected = false;
        // } else {
        //   console.log('not disconnected');
        // }
        console.log("not disconnected");
    }
}
function convertDocToObj(doc) {
    doc._id = doc._id.toString();
    if (doc.timestamp) {
        doc.timestamp = doc.timestamp.toString();
    }
    return doc;
}
const db = {
    connect,
    disconnect,
    convertDocToObj
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);


/***/ })

};
;